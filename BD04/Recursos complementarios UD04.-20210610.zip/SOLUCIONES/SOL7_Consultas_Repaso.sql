﻿-- 1. Para los departamentos en los que hay algún empleado cuyo salario sea mayor de 2.400€ al mes, 
-- hallar el número de empleados y la suma de sus salarios, comisiones y número de hijos.

SELECT NUMDE, COUNT(NUMEM) NUMEMPLE, SUM(SALAR) SUMSALAR, SUM(COMIS) SUMCOMIS, SUM(NUMHI) AS SUMNUMHIJOS
FROM TEMPLE
WHERE NUMDE IN (SELECT DISTINCT NUMDE FROM TEMPLE WHERE SALAR > 2400)
GROUP BY NUMDE
ORDER BY NUMDE;

-- Recordar que la función SUM descarta los valores NULL.


-- 2. Para los departamentos en los que la antigüedad media de sus empleados supere a la antigüedad media de la empresa, 
-- hallar el salario mínimo, el salario medio y el salario máximo.

SELECT NUMDE, MIN(SALAR) AS MINIMO, FORMAT(AVG(SALAR),2) AS MEDIA, MAX(SALAR) MAXIMO
FROM TEMPLE
GROUP BY NUMDE
HAVING AVG(DATEDIFF(CURRENT_DATE,FECIN)) >
  (SELECT AVG(DATEDIFF(CURRENT_DATE,FECIN)) FROM TEMPLE)
ORDER BY NUMDE;

-- Ó

SELECT NUMDE, MIN(SALAR) AS MINIMO, FORMAT(AVG(SALAR),2) AS MEDIA, MAX(SALAR) MAXIMO
FROM TEMPLE
GROUP BY NUMDE
HAVING AVG(TIMESTAMPDIFF(YEAR,FECIN,CURDATE())) > (SELECT AVG(TIMESTAMPDIFF(YEAR, FECIN,CURDATE())) FROM TEMPLE)
ORDER BY NUMDE;

-- 3. Para los departamentos en los que haya algún empleado que cumpla a lo largo del año 50 años de antigüedad y 
-- tales que la media de hijos por cada uno de estos empleados sea superior a 1,
-- hallar el salario medio de estos empleados.

SELECT NUMDE, FORMAT(AVG(SALAR),2) AS MEDIASALAR
FROM TEMPLE
WHERE YEAR(CURRENT_DATE) - YEAR(FECIN) >= 50
GROUP BY NUMDE
HAVING AVG(NUMHI) > 1
ORDER BY NUMDE;

-- En este caso tenemos en cuenta los empleados que tengan a dia de hoy 50 años de antigüedad

SELECT NUMDE, FORMAT(AVG(SALAR),2) AS MEDIASALAR
FROM TEMPLE
WHERE TIMESTAMPDIFF(YEAR, FECIN,CURDATE()) >= 50
-- YEAR(FROM_DAYS(DATEDIFF(CURRENT_DATE,FECIN))) >= 50
      
GROUP BY NUMDE
HAVING AVG(NUMHI) > 1
ORDER BY NUMDE;



-- 4. Agrupando por número de hijos, hallar la media entre el salario total  y el total de hijos 
-- y la media entre la comisión total y el total hijo.
SELECT NUMHI, SUM(SALAR) / SUM(NUMHI) AS 'SALAR/HIJOS', SUM(COMIS)/SUM(NUMHI) 'COMIS/HIJOS'
FROM TEMPLE
WHERE NUMHI > 0
GROUP BY NUMHI
ORDER BY NUMHI;

-- 5. Para los departamentos en los que algún empleado tiene comisión, hallar cuantos empleados hay de media por cada extensión telefónica.
-- con WHERE
SELECT NUMDE, TRUNCATE(COUNT(*)/COUNT(DISTINCT EXTEL),0) AS 'EMPLEADOS/EXTEL'
FROM TEMPLE

WHERE NUMDE IN (SELECT DISTINCT NUMDE
                 FROM TEMPLE
                 WHERE COMIS IS NOT NULL)
GROUP BY NUMDE
ORDER BY NUMDE;

-- con HAVING
SELECT NUMDE, TRUNCATE(COUNT(*)/COUNT(DISTINCT EXTEL),0) AS 'EMPLEADOS/EXTEL'
FROM TEMPLE
GROUP BY NUMDE
HAVING NUMDE IN (SELECT DISTINCT NUMDE
                 FROM TEMPLE
                 WHERE COMIS IS NOT NULL)
ORDER BY NUMDE;

-- Incorrecta, pq no tiene en cuenta para calcular la media los empleados con comisión nula.
SELECT NUMDE, COUNT(*)/ COUNT(DISTINCT EXTEL) AS 'EMPLEADOS/EXTEL'
FROM TEMPLE
WHERE COMIS IS NOT NULL
GROUP BY NUMDE
ORDER BY NUMDE;



-- 6. Para los departamentos cuyo salario medio supera al salario medio de la empresa, hallar cuantas extensiones telefónicas tienen.

SELECT NUMDE, COUNT(DISTINCT EXTEL) AS NUMEXTEL
FROM TEMPLE
GROUP BY NUMDE
HAVING AVG(SALAR) > (SELECT AVG(SALAR) FROM TEMPLE);


-- 7. Hallar el máximo valor de la suma de los salarios por departamentos.

SELECT E.NUMDE,  D.NOMDE, SUM(E.SALAR) SUMSALAR
FROM TEMPLE E,TDEPTO D
WHERE E.NUMDE = D.NUMDE
GROUP BY NUMDE
HAVING SUM(SALAR) >= ALL (SELECT SUM(SALAR)
                          FROM TEMPLE
                          GROUP BY NUMDE);

-- Con tablas derivadas

SELECT D.NOMDE, E.NUMDE,SUM(E.SALAR) AS S
FROM TEMPLE E,TDEPTO D
WHERE E.NUMDE = D.NUMDE
GROUP BY NUMDE
HAVING SUM(SALAR) =(
					SELECT MAX(T.S) AS MAXSALAR
					FROM (SELECT SUM(SALAR) AS S
						  FROM TEMPLE
						  GROUP BY NUMDE) AS T);


-- 8. Para los departamentos cuyo director lo sea en funciones, hallar el número de empleados y la suma de sus salarios, 
-- comisiones y número de hijos.

-- SUBORDINADA
SELECT NUMDE, COUNT(*) TMPLEADOS, SUM(SALAR) TSALARIO, SUM(COMIS) TCOMIS, SUM(NUMHI) THIJOS
FROM TEMPLE
WHERE NUMDE IN (SELECT NUMDE
                FROM TDEPTO
                WHERE TIDIR = 'F')
GROUP BY NUMDE
ORDER BY NUMDE;


-- JOIN -- no entra en esta evaluación
SELECT TE.NUMDE, COUNT(*) TMPLEADOS, SUM(TE.SALAR) TSALARIO, SUM(TE.COMIS) TCOMIS, SUM(TE.NUMHI) THIJOS
FROM TEMPLE TE, TDEPTO TD
WHERE TE.NUMDE = TD.NUMDE
AND TD.TIDIR = 'F'
GROUP BY TD.NUMDE
ORDER BY TE.NUMDE;


